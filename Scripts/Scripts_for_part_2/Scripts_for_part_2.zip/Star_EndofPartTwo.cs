﻿using UnityEngine;
using System.Collections;

public class Star {

    public string starName { get; protected set; }
    public int numberOfPlanets { get; protected set; }

    public Star(string name, int planets)
    {
        this.starName = name;
        this.numberOfPlanets = planets;
    }

}
